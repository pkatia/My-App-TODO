(function() {
    var app = angular.module('ShopAdmin');

    app.controller('CustomersController',['$scope', '$customers', '$products', function($scope, $customers, $products){

        var controller = this;

        this.added = $customers.all;

        this.newCustomer = {id: undefined, firstName: undefined, lastName: undefined, cart: [], status: undefined};
        this.currentlyEditable = undefined;
        this.editableBackup = {};

        this.add = function  () {
            $customers.add(this.newCustomer);
            this.clearNewCustomer();
        };

        this.clearNewCustomer = function () {
            this.newCustomer = {id: undefined, firstName: undefined, lastName: undefined, cart: [], status: undefined};
        };

        this.edit = function  (customer) {
            this.cancelEdit(this.currentlyEditable);
            this.currentlyEditable = customer;
            this.editableBackup = {
                firstName : customer.firstName,
                lastName : customer.lastName,
            };
            customer.editable = !customer.editable;
        };

        this.save = function (customer){
            customer.editable = !customer.editable;
            this.editableBackup = {};
            this.currentlyEditable = undefined;
        };

        this.cancelEdit = function (customer) {
            if (!customer) {
                return;
            };
            customer.firstName = this.editableBackup.firstName;
            customer.lastName = this.editableBackup.lastName;
            customer.editable = !customer.editable;
            this.editableBackup = {};
            this.currentlyEditable = undefined;
        };

        this.remove = function(customer){
            $customers.remove(customer);
        };

        this.total = function (customer){
            return $customers.getCheque(customer);
        };

        this.getAmount = function (customer){
            return $customers.getAmountOfProducts(customer);
        };

        $scope.$on('$destroy', function(){
            controller.cancelEdit(controller.currentlyEditable);
        });
    }]);
})();
