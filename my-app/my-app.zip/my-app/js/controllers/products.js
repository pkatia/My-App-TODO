(function() {
    var app = angular.module('ShopAdmin');

    app.controller('ProductsController',['$scope', '$categories', '$products', function($scope, $categories, $products){

        var controller = this;

        this.categories = $categories;
        this.added = $products.all;

        this.newProduct = {name: undefined ,category:1, price: undefined, status: undefined};

        this.nextId = 10;
        this.currentlyEditable = undefined;
        this.editableBackup = {};

        this.setCategory = function(product,category) {
            product.category = category.id;
        };

        this.add = function  () {
            $products.add(this.newProduct);
            this.clearNewProduct();
        };

        this.clearNewProduct = function () {
            this.newProduct = {name: undefined ,category:1, price: undefined, status: undefined};
        };

        this.edit = function  (product) {
            this.cancelEdit(this.currentlyEditable);
            this.currentlyEditable = product;
            this.editableBackup = {
                name : product.name,
                category : product.category,
                price : product.price,
            };
            product.editable = !product.editable;
        };

        this.save = function (product){
            product.editable = !product.editable;
            this.editableBackup = {};
            this.currentlyEditable = undefined;
        };

        this.cancelEdit = function (product) {
            if (!product) {
                return;
            };
            product.name = this.editableBackup.name;
            product.category = this.editableBackup.category;
            product.price = this.editableBackup.price;
            product.editable = !product.editable;
            this.editableBackup = {};
            this.currentlyEditable = undefined;
        };

        this.remove = function (product){
            $products.remove(product);
        };

        $scope.$on('$destroy', function(){
            controller.cancelEdit(controller.currentlyEditable);
        });

    }]);

})();
