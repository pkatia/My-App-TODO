(function() {
    var app = angular.module('ShopAdmin');

    app.controller('ShoppingCartsController',['$scope', '$routeParams','$categories','$customers','$products', function($scope,$routeParams,$categories,$customers,$products){

        var controller = this;

        this.customer = $customers.byId($routeParams.customer_id);
        this.categories = $categories;
        this.products = $products;
        this.activeProduct = $products.getFirstActive();

        this.product = function(id) {
            return $products.byId(id);
        };

        this.category = function(id) {
            return $categories.byId(($products.byId(id)).category);
        };

        this.setProduct = function(purchase, product) {
            purchase.product = product.id;
        };

        this.newPurchase = {product: this.activeProduct.id, amount: undefined};
        this.currentlyEditable = undefined;
        this.editableBackup = {};

        this.clearNewPurchase = function () {
            this.newPurchase = {product: this.activeProduct.id, amount: undefined};
        };

        this.add = function  () {
            this.customer.cart.push({
                product: this.newPurchase.product,
                amount: this.newPurchase.amount,
            });
            this.clearNewPurchase();
        };

        this.remove = function (purchase) {
            for (var i=0; i<this.customer.cart.length; i++){
                if (this.customer.cart[i].product === purchase.product){
                    this.customer.cart.splice(i,1);
                    break;
                }
            }
        };

        this.save = function  (purchasedItem) {
            purchasedItem.editable = !purchasedItem.editable;
            this.currentlyEditable = undefined;
        };

        this.edit = function  (purchasedItem) {
            this.cancelEdit(this.currentlyEditable);
            this.currentlyEditable = purchasedItem;
            this.editableBackup = {
                product : purchasedItem.product,
                amount : purchasedItem.amount,
            };
            purchasedItem.editable = !purchasedItem.editable;
        };

        this.cancelEdit = function  (purchasedItem) {
            if (!purchasedItem) {
                return;
            };
            purchasedItem.product = this.editableBackup.product;
            purchasedItem.amount = this.editableBackup.amount;
            purchasedItem.editable = !purchasedItem.editable;
            this.editableBackup = {};
            this.currentlyEditable = undefined;
        };

        this.total = function () {
            return $customers.getCheque(this.customer);
        };

        this.calcAltogether = function  (customer) {
            return $customers.getCheque(customer);
        };

        $scope.$on('$destroy', function(){
            controller.cancelEdit(controller.currentlyEditable);
        });
    }]);

})();
