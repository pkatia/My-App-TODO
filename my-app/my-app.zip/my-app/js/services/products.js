(function() {
    var app = angular.module('ShopAdmin');

    app.factory('$products', [function () {
        function Products(){
            this.all = [
                {id:1, name: 'Lime' ,category:5, price: 2, status: 'active'},
                {id:2, name: 'Table' ,category:6, price: 38, status: 'active'},
                {id:3, name: 'Nikon D3200' ,category:4, price: 350, status: 'active'},
                {id:4, name: 'Sony Xperia' ,category:4, price: 280, status: 'active'},
                {id:5, name: 'Photoshop CS9' ,category:7, price: 99, status: 'active'},
                {id:6, name: 'Wrench' ,category:8, price: 50, status: 'active'},
                {id:7, name: 'Hot Wheels Car' ,category:9, price: 10, status: 'active'},
                {id:8, name: 'The Martian' ,category:2, price: 1, status: 'active'},
                {id:9, name: 'Black Square Painting' ,category:1, price: 1500000, status: 'active'},
            ];
            this.nextId = 10;
        }

        var def = Products.prototype;

        def.byId = function(id){
            for (var i=0; i<this.all.length; i++){
                if (this.all[i].id === id){
                    return this.all[i];
                }
            }
        };

        def.add = function(product){
            this.all.push({
                id: this.nextId,
                name: product.name,
                category: product.category,
                price: product.price,
                status: 'active',
            });
            this.nextId++;
        };

        def.remove = function (product) {
            for (var i=0; i<this.all.length; i++){
                if (this.all[i].id === product.id){
                    this.all[i].status = 'removed';
                    break;
                }
            }
        };

        def.getFirstActive = function(){
            for (var i=0;i<this.all.length;i++){
                if (this.all[i].status === 'active'){
                    return this.all[i];
                };
            };
        };
        return new Products();
    }]);

})();
