(function() {
    var app = angular.module('ShopAdmin');

    app.factory('$customers', ['$products', function ($products) {
        function Customers(){
            this.all = [
                {id:1, firstName: 'Katherin', lastName: 'Saliy', cart:[
                    {product: 4 , amount: 2 },
                    {product: 3 , amount: 1},
                    {product: 1 , amount: 4},
                ], status: 'active'},
                {id:2, firstName: 'Marko', lastName: 'Ivaniv', cart:[
                    {product: 2 , amount: 3 },
                    {product: 4 , amount: 5},
                    {product: 5 , amount: 1},
                ], status: 'active'},
                {id:3, firstName: 'Taras' , lastName : 'Saban', cart:[], status: 'active'},
            ];
            this.nextId = 4;
        }

        var def = Customers.prototype;

        def.byId = function(id){
            for (var i=0; i<this.all.length; i++){
                if (this.all[i].id == id){
                    return this.all[i];
                }
            }
        };

        def.add = function(customer){
            this.all.push({
                id: this.nextId,
                firstName: customer.firstName,
                lastName: customer.lastName,
                cart: [],
                status: 'active',
            });
            this.nextId++;
        };

        def.remove = function (customer) {
            for (var i=0; i<this.all.length; i++){
                if (this.all[i].id === customer.id){
                    this.all[i].status = 'removed';
                    break;
                }
            }
        };

        def.getCheque = function (customer) {
            var sum = 0;
            for (var i=0; i<customer.cart.length; i++){
                sum = sum + $products.byId(customer.cart[i].product).price * customer.cart[i].amount;
            }
            return sum;
        };

        def.getAmountOfProducts = function(customer){
            return customer.cart.length;
        };

        return new Customers();
    }]);

})();
